#include "types.h"
#include "stat.h"
#include "user.h"

char buf[1024*100] = {0};
char temp[1] = {0};

int
strncmp(const char *p, const char *q,int n)
{
  while(*p && *p == *q && n > 0)
  {
    p++, q++;
    n--;
  }
  return (uchar)*p - (uchar)*q;
}

char*
strcat(char *s, const char *t)
{
    char *os;

    os = s;
    while (*s) {
        s++;
    }
    while ((*s++ = *t++) != 0) {
        ;
    }
    return os;
}


int main(int argc, char *argv[])
{
    int cflag = 0;
    int dflag = 0;
    int iflag = 0;
    int fd=0;
    
    

    // Parse command line arguments
    for (int i = 1; i < argc; i++) {
        if (strncmp(argv[i], "-c", 2) == 0) {
            cflag = 1;
        }
        else if (strncmp(argv[i], "-d", 2) == 0) {
            dflag = 1;
        }
        else if (strncmp(argv[i], "-i", 2) == 0) {
            iflag = 1;
        }
        else {
            fd = open(argv[i], 0);
            if (fd < 0) {
                printf(1, "uniq: cannot open %s\n", argv[i]);
                exit();
            }
        }
    }

    // If no filename is specified, read from stdin
    if (argc == 1) {
        fd = 0;
    }
    while (read(fd, temp, 1) > 0) {
        strcat(buf, temp);
    }


    uniq( cflag, dflag, iflag, buf);


    close(fd);
    exit();
}