#include "types.h"
#include "stat.h"
#include "user.h"

int
strncmp(const char *p, const char *q,int n)
{
  while(*p && *p == *q && n > 0)
  {
    p++, q++;
    n--;
  }
  return (uchar)*p - (uchar)*q;
}



int
strcasecmp(const char *s1, const char *s2)
{
    while (*s1 && *s2) {
        char c1 = *s1++;
        char c2 = *s2++;
        if (c1 >= 'A' && c1 <= 'Z') {
            c1 += 'a' - 'A';
        }
        if (c2 >= 'A' && c2 <= 'Z') {
            c2 += 'a' - 'A';
        }
        if (c1 != c2) {
            return c1 - c2;
        }
    }
    return *s1 - *s2;
}



void
fun_uniq(int fd, int c, int d, int i)
{
    printf(1, "Uniq command is getting executed in user mode\n");
    char buf[1024];
    int n;
    int noOfTimesRepeated = 1;
    char prevLine[512] = {0};
    char currLine[512] = {0};
    int currLineIndex = 0;
    int line_count = 0;

    while (1) {
        n = read(fd, buf, sizeof(buf));
        if (n == 0) {
            break;
        }
        for (int j = 0; j < n; j++) {
            if (buf[j] == '\n') {
                if (line_count == 0) {
                    strcpy(prevLine, currLine);
                    line_count++;
                    memset(currLine, 0, sizeof(currLine));
                    currLineIndex = 0;
                    continue;
                }
                currLineIndex = 0;
                if (i == 1) {
                    if (strcasecmp(prevLine, currLine) == 0) {
                        noOfTimesRepeated++;
                    } else {
                        if (noOfTimesRepeated > 1) {
                                if (c == 1) {
                                    printf(1, "%d %s\n", noOfTimesRepeated, prevLine);
                                } else {
                                    printf(1, "%s\n", prevLine);
                                }
                        } else if (noOfTimesRepeated == 1) {
                            if (d == 0) {
                                if (c == 1) {
                                    printf(1, "%d %s\n", noOfTimesRepeated, prevLine);
                                } else {
                                    printf(1, "%s\n", prevLine);
                                }
                            }
                        }
                        noOfTimesRepeated = 1;
                        strcpy(prevLine, currLine);
                    }
                } else {
                    if (strncmp(prevLine, currLine, strlen(currLine)) == 0) {
                        noOfTimesRepeated++;
                    } else {
                        if (noOfTimesRepeated > 1) {
                                if (c == 1) {
                                    printf(1, "%d %s\n", noOfTimesRepeated, prevLine);
                                } else {
                                    printf(1, "%s\n", prevLine);
                                }
                        } else if (noOfTimesRepeated == 1) {
                            if (d == 0) {
                                if (c == 1) {
                                    printf(1, "%d %s\n", noOfTimesRepeated, prevLine);
                                } else {
                                    printf(1, "%s\n", prevLine);
                                }
                            }
                        }
                        noOfTimesRepeated = 1;
                        strcpy(prevLine, currLine);
                    }
                }
                memset(currLine, 0, sizeof(currLine));
            } else {
                currLine[currLineIndex] = buf[j];
                currLineIndex++;
            }
        }
    }
    if (currLineIndex > 0) {

        if (i == 1) {
            if (strcasecmp(prevLine, currLine) == 0) {
                noOfTimesRepeated++;
            } else {
                if (noOfTimesRepeated > 1) {
                    
                        if (c == 1) {
                            printf(1, "%d %s\n", noOfTimesRepeated, prevLine);
                        } else {
                            printf(1, "%s\n", prevLine);
                        }
                    
                } else if (noOfTimesRepeated == 1) {
                    if (d == 0) {
                        if (c == 1) {
                            printf(1, "%d %s\n", noOfTimesRepeated, prevLine);
                        } else {
                            printf(1, "%s\n", prevLine);
                        }
                    }
                }
                noOfTimesRepeated = 1;
                strcpy(prevLine, currLine);
            }
        } else {
            if (strncmp(prevLine, currLine, strlen(currLine)) == 0) {
                noOfTimesRepeated++;
            } else {
                if (noOfTimesRepeated > 1) {
                    
                        if (c == 1) {
                            printf(1, "%d %s\n", noOfTimesRepeated, prevLine);
                        } else {
                            printf(1, "%s\n", prevLine);
                        }
                    
                } else{
                    if (d != 1) {
                        if (c == 1) {
                            printf(1, "%d %s\n", noOfTimesRepeated, prevLine);
                        } else {
                            printf(1, "%s\n", prevLine);
                        }
                    }
                }
                noOfTimesRepeated = 1;
                strcpy(prevLine, currLine);
            }
        }
    }
    if (noOfTimesRepeated > 1) {
        
            if (c == 1) {
                printf(1, "%d %s\n", noOfTimesRepeated, prevLine);
            } else {
                printf(1, "%s\n", prevLine);
            }
        
    } else {
        if (d != 1) {
            if (c == 1) {
                printf(1, "%d %s\n", noOfTimesRepeated, prevLine);
            } else {
                printf(1, "%s\n", prevLine);
            }
        }
    }
}

int main(int argc, char *argv[])
{
    int cflag = 0;
    int dflag = 0;
    int iflag = 0;
    int fd=0;

    // Parse command line arguments
    for (int i = 1; i < argc; i++) {
        if (strncmp(argv[i], "-c", 2) == 0) {
            cflag = 1;
        }
        else if (strncmp(argv[i], "-d", 2) == 0) {
            dflag = 1;
        }
        else if (strncmp(argv[i], "-i", 2) == 0) {
            iflag = 1;
        }
        else {
            fd = open(argv[i], 0);
            if (fd < 0) {
                printf(1, "uniq: cannot open %s\n", argv[i]);
                exit();
            }
        }
    }

    // If no filename is specified, read from stdin
    if (argc == 1) {
        fd = 0;
    }

    fun_uniq(fd, cflag, dflag, iflag);

    close(fd);
    exit();
}