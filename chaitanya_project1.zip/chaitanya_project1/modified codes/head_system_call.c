#include "types.h"
#include "stat.h"
#include "user.h"

char buf[1024*100] = {0};
char temp[1] = {0};


int
strncmp(const char *p, const char *q,int n)
{
  while(*p && *p == *q && n > 0)
  {
    p++, q++;
    n--;
  }
  return (uchar)*p - (uchar)*q;
}

char*
strcat(char *s, const char *t)
{
    char *os;

    os = s;
    while (*s) {
        s++;
    }
    while ((*s++ = *t++) != 0) {
        ;
    }
    return os;
}
        


int main(int argc, char *argv[])
{
    int n = 14;
    int fd=0;

    // Parse command line arguments
    for (int i = 1; i < argc; i++) {
        if (strncmp(argv[i], "-n", 2) == 0) {
            if (i + 1 < argc) {
                n = atoi(argv[i+1]);
                i++;
            }
            else {
                printf(1, "option -n requires an argument\n");
                exit();
            }
        }
        
        else {
            fd = open(argv[i], 0);
            if (fd < 0) {
                printf(1, "head: cannot open %s\n", argv[i]);
                exit();
            }
        }
    }

    // If no filename is specified, read from stdin
    if (argc == 1) {
        fd = 0;
    }

    while (read(fd, temp, 1) > 0) {
        strcat(buf, temp);
    }

    head(n, buf);

    close(fd);
    exit();
}