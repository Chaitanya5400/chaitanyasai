#include "types.h"
#include "stat.h"
#include "user.h"

void
fun_head(int fd, int n)
{
    printf(1, "Head command is getting executed in user mode\n");
    char buf[1024];
    char currLine[512] = {0};
    int i = 0;
    int lines = 0;
    int currLineIndex = 0;

    while(1){
        int k = read(fd, buf, sizeof(buf));
        if (k == 0) {
            printf(1, "%s", currLine);
        }
        for (int j = 0; j < k; j++) {
            if (buf[j] == '\n') {
                if (lines == n) {
                    break;
                }
                printf(1, "%s\n", currLine);
                lines++;
                
                if (i == k) {
                    break;
                }
                i++;

                memset(currLine, 0, sizeof(currLine));
                currLineIndex = 0;
                continue;
            }
            currLine[currLineIndex++] = buf[j];
        }
        if (lines == n) {
            break;
        }
        if (k == 0) {
            break;
        }
    }
}

int
strncmp(const char *p, const char *q,int n)
{
  while(*p && *p == *q && n > 0)
  {
    p++, q++;
    n--;
  }
  return (uchar)*p - (uchar)*q;
}

        


int main(int argc, char *argv[])
{
    int n = 14;
    int fd=0;

    // Parse command line arguments
    for (int i = 1; i < argc; i++) {
        if (strncmp(argv[i], "-n", 2) == 0) {
            if (i + 1 < argc) {
                n = atoi(argv[i+1]);
                i++;
            }
            else {
                printf(1, "option -n requires an argument\n");
                exit();
            }
        }
        
        else {
            fd = open(argv[i], 0);
            if (fd < 0) {
                printf(1, "head: cannot open %s\n", argv[i]);
                exit();
            }
        }
    }

    // If no filename is specified, read from stdin
    if (argc == 1) {
        fd = 0;
    }

    fun_head(fd, n);

    close(fd);
    exit();
}